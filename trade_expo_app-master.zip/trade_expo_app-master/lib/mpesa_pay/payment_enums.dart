enum TransactionType {
  CustomerPayBillOnline,
}

enum TransactionMode { IsLive, IsTesting }